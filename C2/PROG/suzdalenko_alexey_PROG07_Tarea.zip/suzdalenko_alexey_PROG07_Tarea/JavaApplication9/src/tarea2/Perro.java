package tarea2;

public class Perro extends Mamifero {
    
    @Override
    public void mover(){
        System.out.println("Ahora es un perro el que se mueve");
    }
}
