package tarea2;

public class Gato extends Mamifero {
    @Override
    public void mover(){
        System.out.println("Ahora es un gato el que se mueve");
    }
}
