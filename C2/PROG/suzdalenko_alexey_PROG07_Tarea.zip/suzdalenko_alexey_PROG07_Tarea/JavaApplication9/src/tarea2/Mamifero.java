package tarea2;

public class Mamifero {
    
    public Mamifero(){}
    
    public void mover(){
        System.out.println("Ahora es el mamífero el que se mueve");
    }
}
