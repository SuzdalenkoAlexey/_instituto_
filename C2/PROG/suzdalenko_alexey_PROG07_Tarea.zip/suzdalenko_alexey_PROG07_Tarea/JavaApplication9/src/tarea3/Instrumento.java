package tarea3;



abstract class Instrumento {
    public abstract void tocar();
    
    public abstract void tocar(String nota);;
    
    public abstract void afinar();
}
